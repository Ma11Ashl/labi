package com.example.a3laba;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private float currentTextSize = 18f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        @SuppressLint("MissingInflatedId")
        TextView txSurname = findViewById(R.id.txSurname);
        Button btnShowSurname = findViewById(R.id.btnShowSurname);
        Button btnTask1 = findViewById(R.id.btnTask1);
        Button btnChangeColor = findViewById(R.id.btnChangeColor);
        Button btnIncreaseSize = findViewById(R.id.btnIncreaseSize);
        Button btnDecreaseSize = findViewById(R.id.btnDecreaseSize);

        // Показать фамилию
        btnShowSurname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txSurname.setText("Лобода");
            }
        });

        // Показать фамилию вместо названия кнопки
        Button btnTask2 = findViewById(R.id.btnTask1);

        btnTask2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnTask2.setText("Лобода");
            }
        });

        // Изменить цвет фамилии из первой кнопки
        btnChangeColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int color = Color.rgb(
                        (int)(Math.random() * 255),
                        (int)(Math.random() * 255),
                        (int)(Math.random() * 255)
                );
                txSurname.setTextColor(color);
            }
        });

        // Увеличить размер
        btnIncreaseSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentTextSize += 2f;
                txSurname.setTextSize(currentTextSize);
            }
        });

        // Уменьшить размер
        btnDecreaseSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTextSize > 8f) {
                    currentTextSize -= 2f;
                    txSurname.setTextSize(currentTextSize);
                }
            }
        });
    }
}