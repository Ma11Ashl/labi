package com.example.myapplication1112;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class FigureEightView extends View {
    private Paint paint;

    public FigureEightView(Context context) {
        super(context);
        paint = new Paint();
        paint.setColor(Color.BLUE);  // Цвет фигуры
        paint.setStrokeWidth(10f);   // Толщина линии
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);   // Сглаживание
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();

        // Рисуем верхний круг
        canvas.drawCircle(width / 2, height / 3, 100, paint);

        // Рисуем нижний круг
        canvas.drawCircle(width / 2, 2 * height / 3, 100, paint);
    }
}