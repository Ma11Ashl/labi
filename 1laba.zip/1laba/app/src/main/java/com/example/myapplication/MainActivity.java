package com.example.yourapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов
        Button button1 = findViewById(R.id.button1);
        ImageView imageView = findViewById(R.id.imageView);

        // Пример обработки нажатия на кнопку
        button1.setOnClickListener(view -> {
            // Действие при нажатии на кнопку
            imageView.setImageResource(R.drawable.new_image);
        });
    }
}